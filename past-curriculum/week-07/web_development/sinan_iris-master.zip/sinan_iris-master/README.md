# Iris Calculator


## Hosted on [Heroku](https://iris-calculator.herokuapp.com/).

### Uses [custom buildbpack](https://github.com/thenovices/heroku-buildpack-scipy) for scipy dependency.
	

This is a simple Flask app that will predict the [species of Iris](http://scikit-learn.org/stable/auto_examples/datasets/plot_iris_dataset.html) using sci-kit Learn's [KNN](http://scikit-learn.org/stable/modules/generated/sklearn.neighbors.KNeighborsClassifier.html) model.